# Amazon Keyword Research Chrome Extension

A Chrome extension that helps you research keywords on Amazon by fetching autocomplete suggestions and providing estimated search volume, results count, demand, and opportunity metrics.

## Features

- 🔍 Fetch Amazon keyword suggestions in real-time
- 📊 View estimated metrics for each keyword:
  - Search Volume
  - Results Count
  - Demand Score
  - Opportunity Score
- 📥 Download results as CSV
- 🎨 Clean, modern interface
- ⚡ Fast and lightweight

## Installation

### Method 1: Load Unpacked Extension (Development Mode)

1. **Download or Clone this Repository**
   - Download the extension folder to your computer

2. **Open Chrome Extensions Page**
   - Open Google Chrome
   - Go to `chrome://extensions/`
   - Or click the three dots menu → More Tools → Extensions

3. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the Extension**
   - Click "Load unpacked"
   - Navigate to the `amazon-keyword-extension` folder
   - Select the folder and click "Select Folder"

5. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in Chrome toolbar
   - Find "Amazon Keyword Research Tool"
   - Click the pin icon to keep it visible

## Usage

1. **Click the Extension Icon**
   - Click the extension icon in your Chrome toolbar
   - The popup window will open

2. **Enter a Keyword**
   - Type your base keyword in the search box (e.g., "coloriage", "laptop", "coffee maker")
   - Press Enter or click "Search"

3. **View Results**
   - The extension will fetch related keywords from Amazon's autocomplete
   - Results will be displayed in a table with metrics:
     - **Keyword**: The suggested search term
     - **Search Volume**: Estimated monthly searches
     - **Results**: Number of products/results
     - **Demand**: Demand score (higher = more demand)
     - **Opportunity**: Opportunity score (higher = better opportunity)

4. **Download Results**
   - Click the "Download CSV" button to export results
   - The CSV file will be saved to your Downloads folder

## How It Works

### Data Collection
The extension uses Amazon's autocomplete API to fetch keyword suggestions. When you enter a base keyword, it:

1. Sends a request to Amazon's suggestion endpoint
2. Retrieves up to 20 related keywords
3. Processes and calculates metrics for each keyword

### Metrics Explained

- **Search Volume**: Estimated number of monthly searches for the keyword
- **Results**: Approximate number of products/listings on Amazon
- **Demand**: Score indicating how popular the keyword is
- **Opportunity**: Score indicating how easy it is to rank for this keyword (higher search volume with fewer results = better opportunity)

### Important Notes

⚠️ **Metrics Estimation**: The metrics shown are estimated values based on Amazon's autocomplete data and algorithmic calculations. They should be used as relative indicators rather than exact figures.

⚠️ **API Limitations**: Amazon may rate-limit requests. If you see errors, wait a few minutes before trying again.

⚠️ **Fallback Mode**: If the Amazon API is unavailable, the extension will generate common keyword variations as fallback data.

## File Structure

```
amazon-keyword-extension/
├── manifest.json          # Extension configuration
├── popup.html            # Main UI
├── popup.css             # Styling
├── popup.js              # Main logic
├── background.js         # Service worker
├── content.js            # Content script for Amazon pages
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md            # This file
```

## Customization

### Change Amazon Domain
By default, the extension uses `amazon.com`. To change to another domain:

1. Open `manifest.json`
2. Update the `host_permissions` array with your desired domains
3. Open `popup.js`
4. Modify the `amazonDomains` array in the `getAmazonSuggestions()` function

### Adjust Metrics Calculation
To modify how metrics are calculated:

1. Open `popup.js`
2. Find the `processKeywords()` function
3. Adjust the formulas for `searchVolume`, `demand`, and `opportunity`

## Troubleshooting

### Extension Won't Load
- Make sure Developer Mode is enabled
- Check that all files are in the correct folder structure
- Look for errors in `chrome://extensions/` under the extension

### No Results Appearing
- Check your internet connection
- Try a different keyword
- Amazon may be rate-limiting requests - wait and try again
- Check the browser console (F12) for error messages

### CSV Won't Download
- Check Chrome's download permissions
- Make sure popup blockers aren't blocking the download
- Try a different keyword with fewer results

## Privacy & Data

- This extension does NOT collect or store any personal data
- All keyword searches are sent directly to Amazon's public API
- No data is sent to third-party servers
- Downloaded CSV files are stored locally on your computer

## Limitations

- Metrics are estimates, not exact figures
- Rate limiting may apply for frequent searches
- Requires internet connection
- Works with Amazon's public autocomplete API

## Future Improvements

Potential features for future versions:
- Real-time search volume data from multiple sources
- Competition analysis
- Trend tracking
- Bookmark/save favorite keywords
- Multiple marketplace support (US, UK, DE, FR, etc.)
- Historical data tracking
- Export to Excel format

## Support

If you encounter issues or have suggestions:
1. Check the Troubleshooting section above
2. Review the browser console for errors (F12 → Console tab)
3. Make sure you're using the latest version of Chrome

## License

This extension is provided as-is for educational and research purposes.

## Disclaimer

This tool is not affiliated with, endorsed by, or officially connected with Amazon in any way. Amazon and related trademarks are property of Amazon.com, Inc. or its affiliates.

The keyword metrics provided are estimates and should not be considered as guaranteed accurate data. Always verify important business decisions with multiple data sources.

---

**Version**: 1.0.0  
**Last Updated**: December 2025
