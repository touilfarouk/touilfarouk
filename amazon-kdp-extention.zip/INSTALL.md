# Quick Installation Guide

## Install in 5 Steps:

### 1. Open Chrome Extensions
- Go to: `chrome://extensions/`
- Or: Menu (⋮) → More Tools → Extensions

### 2. Enable Developer Mode
- Toggle "Developer mode" in top-right corner

### 3. Load Extension
- Click "Load unpacked" button
- Select the `amazon-keyword-extension` folder
- Click "Select Folder"

### 4. Verify Installation
- You should see "Amazon Keyword Research Tool" in your extensions
- Status should show as "ON"

### 5. Start Using
- Click the extension icon in Chrome toolbar
- Enter a keyword (e.g., "laptop")
- Click "Search"

## That's it! 🎉

For detailed instructions and troubleshooting, see the full README.md file.
